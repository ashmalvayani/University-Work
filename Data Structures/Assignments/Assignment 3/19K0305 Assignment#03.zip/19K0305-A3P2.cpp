#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

/*
 19K-0305
 Basically what I've done in the code is performed in-order traversal with a little changes, before calling on to the left child it will simply
 add the data and will keep on doing that until the pointer reachers leaf node. Once the leaf node is found the final sum is pushed in vector.
 after storing right is called and when found NULL, it will simply subtract the leaf's data from overall path's sum and will give output directly.
 vector is used only to display proper outputs like was required in sample output.
*/

class Node{
public:
	int data;
	Node* lchild;
	Node* rchild;
	
	// constructor of Node class.
	Node(int data){
		this->data = data;
		this->lchild = this->rchild = NULL;
	}
};

class BinarySearchTree{
private:
	Node* root;
	int *sumTotal;
	vector<int> v1;
public:
	BinarySearchTree(){
		root = NULL;
		sumTotal = NULL;
	}
	void insert(int key){
		Node* temp = root, *r, *temp2;
		if(!root){
			temp2 = new Node(key);
			root = temp2;
			return;
		}
		while(temp){
			r=temp;
			if(key<temp->data)
				temp= temp->lchild;
			else if(key > temp->data)
				temp= temp->rchild;
			else
				return;
		}
		temp2 = new Node(key);
		
		if(key<r->data)	r->lchild = temp2;
		else r->rchild = temp2;
	}

	// wrapper function to pass private variable to function
	void InOrderWrapper(){
		InOrderR(root);
	}
	
	// driver levelOrder function
	void InOrderR(Node* ptr){
		static int sum = 0;
		if(!ptr)
			return;
		sum += ptr->data;
		InOrderR(ptr->lchild);
		
		// push the sum into vector
		if(!ptr->lchild && !ptr->rchild)
			v1.push_back(sum);
		
		InOrderR(ptr->rchild);
		sum -= ptr->data;		
	}
	
	// level order traversal for particular level
	void WriteToFile(){
		ofstream outfile("P2Output.txt",ios::out);
		if(!outfile){
			exit(0);
		}
		// will store the outputs in file
		for(int i=0; i<v1.size(); i++){
			outfile << v1.at(i);
			if(i!= v1.size()-1)
				outfile << "-";  // for proper formatting only
		}
		
		outfile.close();
		cout << "Output stored in P2Output.txt, please check the file.\n";
	}
};

int main(){
	
	// filing, input stream
	ifstream infile("P2.txt",ios::in);
	if(!infile){
		cout << "File not opened, please create P2.txt file";
		exit(0);
	}
	
	BinarySearchTree Tree;
	int number;
	
	// if file is opened then move further otherwise stop
	while(!infile.eof()){
		infile >> number;
		Tree.insert(number);
	}
	
	// closing the file
	infile.close();
	
	// calling function to check for sum of paths
	Tree.InOrderWrapper();
	
	// to write output to file
	Tree.WriteToFile();
	return 0;
}
