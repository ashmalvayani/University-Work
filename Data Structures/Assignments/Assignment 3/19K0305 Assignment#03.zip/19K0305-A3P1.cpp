#include <iostream>
#include <fstream>
using namespace std;

/*
	19k-0305
	Basically what I've done is simply implemented binary search tree and performed level order traversal and stored the sum in array then
	simply stored it in file.
*/

class Node{
public:
	int data;
	Node* lchild;
	Node* rchild;
	
	// public constructor of Node class
	Node(int data){
		this->data = data;
		this->lchild = this->rchild = NULL;
	}
};

class BinarySearchTree{
private:
	Node* root;
	int *sumTotal;
	int hei;
public:
	BinarySearchTree(){
		root = NULL;
		sumTotal = NULL;
		hei = 0;
	}
	
	// inserts the element
	void insert(int key){
		Node* temp = root, *r, *temp2;
		if(!root){
			temp2 = new Node(key);
			root = temp2;
			return;
		}
		while(temp){
			r=temp;
			if(key<temp->data)
				temp= temp->lchild;
			else if(key > temp->data)
				temp= temp->rchild;
			else
				return;
		}
		temp2 = new Node(key);
		
		if(key<r->data)	r->lchild = temp2;
		else r->rchild = temp2;
	}

	// wrapper function to pass private variable to function
	void LevelOrderWrapper(){
		LevelOrder(root);
	}
	
	// driver levelOrder function
	void LevelOrder(Node* ptr){
		hei= height(ptr);
		sumTotal = new int[hei];
		for(int i=1; i<=hei; i++)
			sumTotal[i-1]= LevelOrderTraversal(ptr,i);
	}
	
	// level order traversal for particular level
	int LevelOrderTraversal(Node* ptr, int Height){
		static int sum = 0;
		if(!ptr) return sum;
		if(Height==1) 
			sum += ptr->data;
		else if(Height>1){
			LevelOrderTraversal(ptr->lchild, Height-1);
			LevelOrderTraversal(ptr->rchild, Height-1);
		}
	}
	
	// calculates the height of node/tree
	int height(Node* p){
		int x=0, y=0;
		if(!p)
			return 0;
		x = height(p->lchild);
		y = height(p->rchild);
		
		return x>y ? x+1: y+1;
	}
	
	// calculates sum, modifies it
	void CalSum(){
		for(int i= hei-1; i>0; i--)
			sumTotal[i] -= sumTotal[i-1];
	}
	
	// function to write it in file
	void WriteToFile(){
		ofstream outfile("P1Output.txt",ios::out);
		if(!outfile){
			exit(0);
		}
		
		for(int i=0; i<hei; i++){
			outfile << sumTotal[i];
			if(i!=hei-1)
				outfile << "-";
		}
		outfile.close();
		
		cout << "Output stored in P1Output.txt, please check the file.\n";
	}
	
};

int main(){
	
	// filing, input stream
	ifstream infile("P1.txt",ios::in);
	if(!infile){
		cout << "File not opened, please create P1.txt file";
		exit(0);
	}
	
	BinarySearchTree Tree;
	int number;
	
	// if file is opened then move further otherwise stop
	while(!infile.eof()){
		infile >> number;
		Tree.insert(number);
	}
	
	// closing the file
	infile.close();
	
	Tree.LevelOrderWrapper();
	Tree.CalSum();
	
	// to write output to file
	Tree.WriteToFile();
	return 0;
}
