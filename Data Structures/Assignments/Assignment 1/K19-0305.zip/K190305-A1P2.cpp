#include <iostream>
#include <fstream>
using namespace std;

class Palindrome{
	private:
		int size;
		int *Array;
	
	public:
		// paramertized constructor
		Palindrome(int size, int Arr[]){
			this->size= size;
			this->Array= Arr;
		}
		
		// main driver function
		bool CheckPlaindrome(){
			int temp[size], temp2[size], remainder, newNumber=0;
	
			for(int i=0; i<size; i++)
				temp2[i]= Array[i];
			
				for(int i=0; i<size; i++){
					while(temp2[i]!=0){
						remainder= temp2[i]%10;
						newNumber = remainder + (newNumber*10);
						temp2[i] /= 10;
					}
					temp[i]= newNumber;
					newNumber=0;
				}
				
				int count=0;
				
				for(int i=0, k=size-1; i<size, k>=0; i++, k--){
					if(temp[i]==Array[k]){
						count++;
					}
				}
				if(count==size)
					return true;
				else
					return false;
		}
};


int main(){
	// filing, input stream
	ifstream ptr("P2.txt");
	if(!ptr){
		cout << "File not found, first create a file with name P2.txt";
		exit(0);
	}
	// if file is opened then move further otherwise stop
	int size;
	ptr >> size;
	
	int Arr[size];
	for(int i=0; i<size; i++){
		ptr >> Arr[i];
	}
	// closing file
	ptr.close();
	
	Palindrome P(size, Arr);
	bool check = P.CheckPlaindrome();
	
	// filing, output stream
	ofstream out("P2Output.txt", ios:: out);
	// if file is opened then move further otherwise stop
	if(!out){
		cout << "Output file not created";
		exit(0);
	}
	if(check){
		out << "YES";
	}
	else
		out << "NO";
	
	cout << "Please check P2Output.txt file to see the result stored in file";
	
	// closing file
	out.close();
	return 0;
}

