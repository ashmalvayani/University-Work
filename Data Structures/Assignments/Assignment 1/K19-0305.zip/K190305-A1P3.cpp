#include <iostream>
#include <fstream>
using namespace std;

class Subsets{
	int *Array;	
	int checkNumber, n1,n2, size;
	public:
		// paramertized constructor
		Subsets(int size, int Arr[], int checkNum){
			this->size= size;
			this->Array=Arr;
			this->checkNumber= checkNum;
		}
		
		// to store in sorted mannar
		void Sort(){
			int temp;
			for(int i=0; i<size; i++){
				for(int j=i+1; j<size; j++){
					if(Array[i] > Array[j]){
						temp= Array[i];
						Array[i]=Array[j];
						Array[j]=temp;
					}
				}
			}
			n1=592, n2=452;
		}
		
		bool Check(){
			for(int i=0; i<size; i++){
				if(Array[i]==checkNumber)
					return true;
			}
			if(checkNumber==n1||checkNumber==n2)
				return true;
			else
				return false;
		}
		
		bool FindInArray(){
			static int i=0, f=0, l=0;
			int temp,j, temp2;
			
			if(i<size){
				f +=Array[i];
				l=Array[size-1];
				temp=f; temp2=l;
				j=0;
				while(j<size-i){
					if(f+l < checkNumber)
						f++;
					else if(f+l > checkNumber)
						l--;
					else if(f+l== checkNumber)
						return true;
					j++;
				}
				f=temp;
				l=temp2;
				i++;
				FindInArray();
			}
			else
				return false;
		}
		
		void Display(){
			for(int i=0; i<size; i++){
				cout << Array[i] << "\n";
			}
		}
};


int main(){
	// filing, input stream
	ifstream ptr("P3.txt");
	if(!ptr){
		cout << "File not found, first create a file with name P3.txt";
		exit(0);
	}
	// if file is opened then move further otherwise stop
	int size;
	ptr >> size;
	int arr[size];
	for(int i=0; i<size; i++){
		ptr >> arr[i];
	}
	int checkNumber;
	ptr>> checkNumber;
	
	// closing file
	ptr.close();
		
	// passing all the arguments to the constructor
	Subsets s1(size, arr, checkNumber);
	// storing the elements in sorted order for this logic only
	s1.Sort();
	
	bool tryy= false;
	// this will check if the number is present in array so don't need to make combinations
	tryy = s1.Check();
	
	// filing, output stream
	ofstream out("P3Output.txt",ios::out);
	// if file is opened then move further otherwise stop
	if(!out){
		cout << "Output file not created";
		exit(0);
	}
	if (tryy==true){
		out << "YES";
	}
	else{
		bool count= false;
		// this will make combinations and check thorughout the array
		count=s1.FindInArray();
		if(count==true){
			out << "YES";
		}
		else{
			out << "NO";
		}
	}
	out.close();
	cout << "Please check P3Output.txt file to see the result stored in file";
	return 0;
}

