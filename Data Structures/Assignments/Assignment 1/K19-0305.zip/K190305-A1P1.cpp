#include <iostream>
#include <fstream>
using namespace std;

class Boggle{
	int n, m;
	
	public:
		// paramertized constructor
		Boggle(int n, int m){
			this->n= n;
			this->m= m;
		}
		
		// to display the output
		void Output(char ** array){
			for(int i=0; i<n; i++){
				for(int j=0; j<m; j++){
					cout << array[i][j];
				}
				cout << endl;
			}
		}
		
		// to check adjacent in rows
		int checkrow(char** tempArr, string word){
			int mainCount=0, count=0, k=0;
			for(int i=0; i<n; i++){
				for(int j=0; j<m; j++){
					if(tempArr[i][j]=='1' && (tempArr[i][j+1]!='0' && i<n && j<m)){
						count++;	
					if(count==word.length())
						mainCount++;
					}
				}
				count=0;
			}
			return mainCount;
		}
		
		// to check adjacent in columns
		int checkcolumn(char** tempArr, string word){
			int mainCount=0, count=0;
			for(int j=0; j<m; j++){
				for(int i=0; i<n; i++){
					if((tempArr[i][j]=='1') && (count<word.length())){
						count++;
					}
				}
				if(count==word.length()){
					mainCount++;
				}
				count=0;
			}
			return mainCount;
		}
		
		// driver code to call rows, and coulumn functions too
		int BoggleBoggle(char** tempArr, string check){
			for(int i=0; i<n; i++){
				for(int j=0; j<m; j++){
					for(int k=0; k<check.length(); k++){
						if(tempArr[i][j]==check[k]){
							tempArr[i][j]='1';
						}
					}
				}
			}
					
			for(int i=0; i<n; i++){
				for(int j=0; j<m; j++){
					if(tempArr[i][j]!='1'){
						tempArr[i][j]='0';
					}
				}
			}
			int count1= checkrow(tempArr, check);
			int count2= checkcolumn(tempArr, check);
			return count1+ count2;
		}
};

int main(){
	int n,m;
	// filing, input stream
	ifstream ptr("P1.txt");
	if(!ptr){
		cout << "File not found, first create a file with name P1.txt";
		exit(0);
	}
	// if file is opened then move further otherwise stop
	ptr >> n >> m;
	n++; m++;

	// dynamically allocating the memory
	char **array, **array2;
	array= new char *[n];
	array2= new char *[n];
	
	for(int i=0; i<n; i++){
		array[i]= new char[m];
		array2[i]= new char[m];
	}
	
	for(int i=0; i<n; i++){
		for(int j=0; j<m; j++){
			ptr >> array[i][j];
			array2[i][j]= array[i][j];
		}
	}
	
	int num;
	ptr >> num;
	string words[num];
	for(int i=0; i<num; i++)
		ptr >> words[i];
	
	// closing the file
	ptr.close();
	
	// creating an object
	Boggle B1(n,m);
	int arr[num];
	
	// creating a temperory array to hold the original array so that it can be passed again
	for(int i=0; i<num; i++){
		for(int i=0; i<n; i++){
			for(int j=0; j<m; j++){
				array2[i][j] = array[i][j];
			}
		}
		arr[i]=B1.BoggleBoggle(array2, words[i]);
	}
	
	
	// filing, output stream
	ofstream out("P1Output.txt", ios:: out);
	if(!out){
		cout << "Can't create a file.";
		exit(0);
	}
	else{
		cout << "Output stored in file, please check P1Output.txt";
		for(int i=0; i<num; i++){
			out << words[i] << " " << arr[i]*1000 << endl;
		}
	}
	// closing the file
	out.close();
	
	return 0;
}
