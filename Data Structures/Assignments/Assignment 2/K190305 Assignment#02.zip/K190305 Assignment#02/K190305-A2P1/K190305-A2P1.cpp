#include <iostream>
#include <string>
#include <fstream>

using namespace std;

/*
 19K-0305 Q1
 So basically what I've done is I've taken input from file and assigned it to the objects, the driver function MazeProblem will calculate the paths
 of the maze and will push the paths in stack, the display in stack will concatenate the paths into a string and store paths into another data structure linkedlist
 to later sort in on the basis of it's cost, because the recurrsive function's job is just to calculate path, not sort and store it based on cost.
*/

class LNode{
public:
	string data;
	int cost;
	LNode* next;
};

class LinkedList{
private:
	LNode *head, *tail;
	int count;
public:
	LinkedList(){
		head= tail= NULL;
		count =0;
	}
	
	void AddnewNode(string el, int c){
		count++;
		LNode* temp = new LNode;
		temp->data = el;
		temp->cost = c;
		temp->next= NULL;
		if(head==NULL){
			head = tail = temp;
		}
		else{
			tail->next= temp;
			tail = temp;
			temp->next=NULL;
		}
	}
	
	void Display(){
		LNode* p = head;
		int paths=1;
		
		ofstream ptr("P1Output.txt", ios:: out);
		if(!ptr){
			cout << "Output file not created, heap is full.\n";
			exit(0);
		}
		while(p!=NULL){
			ptr << "Path#" << paths << "={";
			ptr << p->data;
			ptr << "} Cost="<< p->cost << endl;
			p=p->next;
			paths++;
		}
		ptr.close();
	}
	
	// will sort the linked list
	void SortLinkedList(){
		LNode* p =head, *q;
		for(int i=1; p!=NULL; i++, p=p->next){
			q=p->next;
			for(int j= i+1; q!=NULL; j++, q=q->next){
				if(p->cost > q->cost){
					int t = p->cost;
					p->cost = q->cost;
					q->cost= t;
					
					string s = p->data;
					p->data = q->data;
					q->data = s;						
				}
			}
		}	
	}
};

class Node{
public:
	int data1;
	int data2;
	Node* next;
};

class stack{
private:
	Node* top;
public:
	stack(){
		top= NULL;
	}
	void push(int i, int j){
		Node* temp = new Node;
		if(!temp){
			cout << "StackOverflow";
		}
		else{
			temp->data1= j;
			temp->data2= i;
			temp->next= top;
			top= temp;
		}
	}
	void pop(){
		if(isEmpty()){}
		else{
			Node* temp= top;
			top= top->next;
			int j = temp->data1;
			int i = temp->data2;
			delete temp;
		}
	}
	
	bool isEmpty(){
		if(top==NULL)
			return true;
		return false;	
	}
	
	// it doesnot displays the path instead just concatenate the paths into a string variable through converting it to string
	string Display(){
		Node* p= top;
		string completePath;
		
		while(p!= NULL){
			completePath += '(';
			completePath += to_string(p->data1);
			completePath += ',';
			completePath += to_string(p->data2);
			completePath += ')';
			if(p->next!=NULL)
				completePath += ',';
			p= p->next;
		}
		return completePath;
	}
	
	int Size(){
		int count=0;
		Node* p= top;
		while(p!= NULL){
			count++;
			p=p->next;
		}
		return count;
	}	
	
	// Transfer data of 1 stack to another in reverse order
	stack& Transfer(stack &s){
		while(!this->isEmpty()){
			s.push(top->data2,top->data1);
			pop();
		}
		return s;
	}
};

class MazePaths{
private:
	int row,column;
	char** maze;
	int sl1, sl2;
	int count;
	int paths;
	stack s;
	LinkedList l1;
public:
	
	MazePaths(){
		row = 0;
		column = 0;
		maze = 0;
		count = 0;
		paths = 0;
	}
	
	// taking inputs from file and assigning to class objects
	void Input(char** maze, int row, int column, int sl1, int sl2, stack &s){
		this->maze = maze;
		this->row = row;
		this->column = column;
		this->sl1 = sl1;
		this->sl2 = sl2;
		this->s = s;
	}
	
	// will check if the marked position is safe or not
	bool isSafe(char** maze, int i, int j){
		if(i>=0 && i<row && j>=0 && j<column && (maze[i][j]=='0' || maze[i][j]=='S' || maze[i][j]=='s' || maze[i][j]=='e'))
			return true;
		return false;
	}
	
	// driver function to calculate paths
	int MazeProblem(char** maze, int sp1, int sp2, stack &s){
		count++;
		if(!isSafe(maze,sp1,sp2))
			return 0;
			
		if(maze[sp1][sp2]=='e'){
			paths++;
			
			// if path is found then just transfer it to a new stack because since it's LIFO, it will be stored in reverse order
			stack s1;
			s1=s.Transfer(s1);
			l1.AddnewNode(s1.Display(),count);
			s=s1.Transfer(s);
			return 0;
		}
		else{	
			maze[sp1][sp2]='!';
			s.push(sp1,sp2+1);
			MazeProblem(maze, sp1, sp2+1,s);
			count--;
			s.pop();
			
			s.push(sp1+1,sp2);
			MazeProblem(maze, sp1+1, sp2,s);
			count--;
			s.pop();
			
			s.push(sp1,sp2-1);
			MazeProblem(maze, sp1, sp2-1,s);
			count--;
			s.pop();
			
			s.push(sp1-1,sp2);
			MazeProblem(maze, sp1-1, sp2,s);
			count--;
			s.pop();
	
			maze[sp1][sp2]='0';
			return paths;
	}
}
	
	// since paths are not sorted on the basis of cost, this function will sort it on the basis of cost.
	void SortAndPrintLinkedList(){
		l1.SortLinkedList();
		l1.Display();
		cout << "Output Stored in 'P2Output.txt', please check it.\n";
	}
};


int main(){
	int row, column;
	int sl1, sl2;
	
	// filing, input stream
	ifstream ptr("P1Inputs.txt");
	if(!ptr){
		cout << "File not opened, please create P1.txt first";
		exit(0);
	}
	
	// if file is opened then move further otherwise stop
	ptr >> row >> column;
	
	// dynamically allocating the memory
	char** maze = new char *[row];
	for(int i=0; i<row; i++)
		maze[i]= new char[column];
		
	for(int i=0; i<row; i++){
		for(int j=0; j<column; j++){
			ptr >> maze[i][j];
			if(maze[i][j]=='S' || maze[i][j]=='s'){
				sl1=i;
				sl2=j;
			}
		}
	}
	// closing the file
	ptr.close();
	
	// pushing the first path of maze
	stack s;
	s.push(sl1,sl2);
		
	MazePaths obj;
	obj.Input(maze, row, column, sl1, sl2,s);
	obj.MazeProblem(maze,sl1,sl2,s);
	obj.SortAndPrintLinkedList();
	return 0;
}
