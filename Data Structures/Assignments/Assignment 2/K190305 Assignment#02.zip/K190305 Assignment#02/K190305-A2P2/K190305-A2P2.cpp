#include <iostream>
#include <fstream>
using namespace std;

/*
 19K-0305
 Basically what I've done is I've taken inputs in input function unlike in main in last question because there is no recurrsion involved.
 three 1d arrays are used 1 will have quota of cpu, 2nd will have requirements of the system, array3 will store the ratio of array2/1
 if ratio is less than 1, then it will consider it as 1 because completing requirements in 0 cycle is not possible.
 I've used the concept of priorty queue in a manner that dequeue is based on priorty where as enqueue is normal (inserted in any order).
*/

class QNode{
public:
	int index;
	int units;
	QNode* next;
	QNode(){}
};

class Queue{
private:
	QNode *front, *rear;
public:
	Queue(){
		front = rear= NULL;
	}
	void Enqueue(int x, int y){
		QNode *temp = new QNode;
		if(temp==NULL){
			cout << "Overflow heap.\n";
			exit(0);
		}
		else{
			temp->index= x;
			temp->units= y;
			temp->next= NULL;
			if(front==NULL)
				front = rear = temp;
			else{
				rear->next= temp;
				rear= temp;
			}
		}
	}
	
	int Dequeue(){
		int x= -1;
		if(isEmpty()){
			cout << "Queue is empty.\n";
		}
		else{
			QNode *p= front;
			int min = p->units, count=0, in=0;
			while(p!=NULL){
				if(p->units < min){
					min = p->units;
					in= count;
				}
				count++;
				p=p->next;
			}
			
			if(in==0){
				p= front;
				front = front->next;
				x= p->index;
				delete p;
			}
			else if(in==count-1){
				p= front;
				while(p->next->units!= min){
					p=p->next;
				}
				x= rear->index;
				QNode *temp = p->next;
				rear = p;
				rear->next= NULL;
				delete temp;
			}
			else{
				p= front;
				while(p->next->units!= min){
					p=p->next;
				}
				x= p->next->index;
				QNode* temp= p->next;
				p->next= temp->next;
				delete temp;
			}
		}
		return x;
	}
	
	bool isEmpty(){
		if(front==NULL)
			return true;
		return false;
	}
};

class RoundRobin{
	Queue Q;
	int size;
	public:
		RoundRobin(){
			size=0;	
		}
		void InputFunction(){
			// filing, input stream
			ifstream ptr("P2Inputs.txt", ios::in);
			if(!ptr){
				cout << "File not opened, plz open P2.txt or check again.\n";
				exit(0);
			}
			// if file is opened then move further otherwise stop
			else{
				ptr >> size;
				int arr[size], arr2[size],arr3[size];
				for(int i=0; i<size; i++)
					ptr >> arr[i];

				for(int i=0; i<size; i++)
					ptr >> arr2[i];

				for(int i=0; i<size; i++){
					ptr >> arr3[i];
					if(arr3[i]>arr2[i])
						arr2[i] = arr3[i]/arr2[i];
					else 
						arr2[i] = 1;
				}
				
				for(int i=0; i<size; i++)
					Q.Enqueue(arr[i],arr2[i]);	
			}
			// closing the file
			ptr.close();
		}
		void RunningFunction(){
			// output stream to store outputs
			ofstream ptr("P2Output.txt",ios::out);
			if(!ptr){
				cout << "Output file not created, exitting.\n";
				exit(0);
			}
			else{
				for(int i=0; i<size; i++){
					ptr << Q.Dequeue() << " "; 
				}
				cout << "Output stored in 'P2Output.txt' file, please check.\n";
			}
			ptr.close();
		}
};

int main(){
	RoundRobin R1;
	R1.InputFunction();
	R1.RunningFunction();
		
	return 0;
}

