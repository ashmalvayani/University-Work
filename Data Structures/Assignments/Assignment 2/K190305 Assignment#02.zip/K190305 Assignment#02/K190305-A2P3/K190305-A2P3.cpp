#include <iostream>
#include <algorithm>
#include <fstream>
#include <cstring>
using namespace std;

/*
 19K-0305
 Basically what I've done is taken inputs form file and applied algorithm as given in the question and stored in the output file.
 for infixToPrefix first reverse the string, apply algorithm and reverse again before returning back to main
 for infixToPostfix simply applied the mentioned algorithm and returned the final output string to main and stored in file.
 used reverse function from algorithm class.
*/

class Node{
	public:
		char data;
		Node* next;
};

class stack{
private:
	Node* top;
public:
	stack(){
		top= NULL;
	}
	void push(char x){
		Node* temp = new Node;
		if(!temp){
			cout << "StackOverflow";
		}
		else{
			temp->data= x;
			temp->next= top;
			top= temp;
		}
	}
	int pop(){
		if(isEmpty()){
			return -1;
		}
		else{
			Node* temp= top;
			top= top->next;
			char x= temp->data;
			delete temp;
			return x;
		}
	}
	
	void Display(){
		Node* p= top;
		while(p!= NULL){
			cout << p->data;
			p= p->next;
		}
	}
	bool isEmpty(){
		if(top==NULL){
			return true;
		}
		return false;
	}
	char isTop(){
		return top->data;
	}
};

class Conversions{
private:
	string infix;
	string revInfix;
	string prefix;
	string postfix;
	stack s1;
public:
	Conversions(){}
	
	// takes the input from file and reverse it
	void Input(){
		ifstream ptr("P3Inputs.txt", ios:: in);
		if(!ptr){
			cout << "File not opened, please create 'P3Inputs.txt' and try again.\n";
			exit(0);
		}
		ptr >> infix;
		ptr.close();
		
		revInfix= infix;
		reverse(revInfix.begin(), revInfix.end());
		for(int i=0; i<revInfix.size(); i++){
			if(revInfix[i]=='(')
				revInfix[i]=')';
			else if(revInfix[i]==')')
				revInfix[i]='(';
		}
	}
	
	// driver function to convert string into prefix
	string ConvertToPrefix(){
		for(int i=0; i<revInfix.size(); i++){
			// if it's an operand, simply store it in output prefix
			if(isOperand(revInfix[i]))
				prefix += revInfix[i];
			else if(revInfix[i]=='(')		// if it's an opening bracket, push it in the stack
				s1.push(revInfix[i]);
			else if(revInfix[i]==')'){		// if it's closing bracker, pop the elments until either stack is empty or encounters another (
				while(!(s1.isEmpty()) && (s1.isTop()!='(')){
					prefix += s1.isTop();
					s1.pop();
				}
				if(s1.isTop()=='(')			// discard the bracket.
					s1.pop();
			}
			else if(CheckOperator(revInfix[i])){	// check for operator
				if(s1.isEmpty())
					s1.push(revInfix[i]);			// of stack is empty simply push it without checking anything
				else{
					if(CheckPrecedence(revInfix[i])>= CheckPrecedence(s1.isTop())){	// if it has higher precedence, just push it on stack
						s1.push(revInfix[i]);
					}
					else{
						while(!(s1.isEmpty())&& (CheckPrecedence(revInfix[i]) < CheckPrecedence(s1.isTop()))){
							prefix += s1.isTop();
							s1.pop();
						}
						s1.push(revInfix[i]);
					}
				}
			}
		}
		
		while(!s1.isEmpty()){
			prefix += s1.isTop();
			s1.pop();
		}
		reverse(prefix.begin(), prefix.end());
		return prefix;
	}
	
	// will return the precedance of the operator
	int CheckPrecedence(char ch){
		return (ch=='+'||ch=='-') ? 1 : (ch=='*' || ch=='/') ? 2 : (ch=='^') ? 3 : -1;
	}
	
	// will return true if character is an operand
	bool isOperand(char ch){
		return ((ch>='a' && ch<='z') || (ch>='A' && ch <='Z') || (ch>='0' && ch<='9')) ? true : false;
	}
	
	// will return true if character is an operator
	bool CheckOperator(char ch){
		return (ch=='+' || ch=='-' || ch=='*' || ch=='/' || ch=='^') ? true : false;
	}
	
	// driver function to convert it to postfix
	string ConvertToPostfix(){
		for(int i=0; i<infix.size(); i++){
			if(isOperand(infix[i])){
				postfix += infix[i];
			}
			else if(infix[i]=='('){
				s1.push(infix[i]);
			}
			else if(CheckOperator(infix[i])){
				if(s1.isEmpty())
					s1.push(infix[i]);
				else if(s1.isTop()=='(')
					s1.push(infix[i]);
				else if(CheckPrecedence(infix[i]) > CheckPrecedence(s1.isTop()))
					s1.push(infix[i]);
				else{
					while(!(s1.isEmpty())&& (CheckPrecedence(infix[i]) <= CheckPrecedence(s1.isTop()))){
						postfix += s1.isTop();
						s1.pop();
					}
					s1.push(infix[i]);
					
				}
			}
			else if(infix[i]==')'){
				while(!(s1.isEmpty()) && (s1.isTop()!='(')){
					postfix += s1.isTop();
					s1.pop();
					
				}
				if(s1.isTop()=='(')
					s1.pop();
			}
		}
		while(!s1.isEmpty()){
			postfix += s1.isTop();
			s1.pop();
		}
		return postfix;
	}
};

int main(){
	Conversions C1;
	// this function will open and read inputs from file
	C1.Input();
	// storing output in file
	ofstream ptr("P3Output.txt",ios::out);
	if(!ptr){
		cout << "File not created, heap is full please try again.\n";
		exit(0);
	}
	ptr << C1.ConvertToPrefix() << endl;
	ptr << C1.ConvertToPostfix() << endl;
	cout << "Output stored in 'P3Output.txt' please check the file.\n";
	// closing the file
	ptr.close();
	return 0;
}
